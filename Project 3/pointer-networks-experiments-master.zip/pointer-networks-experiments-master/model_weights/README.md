# Model weights

Models at various stages of training, either for ordering single numbers, or sums or numbers (`model_weights_sums_64`). 64 is the size of the hidden layer.

